from sqlalchemy import Column, Integer, String, Float, Date, DateTime, ForeignKey, Boolean, func
from sqlalchemy.orm import relationship
from .database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(150), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(20), default="customer", nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    bookings = relationship("Booking", back_populates="user")

class Bike(Base):
    __tablename__ = "bikes"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    brand = Column(String(80), nullable=False)
    category = Column(String(50), nullable=False)
    price_per_day = Column(Float, nullable=False)
    image_url = Column(String(500), default="")
    description = Column(String(500), default="")
    available = Column(Boolean, default=True)
    bookings = relationship("Booking", back_populates="bike")

class Booking(Base):
    __tablename__ = "bookings"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    bike_id = Column(Integer, ForeignKey("bikes.id"), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    total_amount = Column(Float, nullable=False)
    status = Column(String(30), default="confirmed")
    created_at = Column(DateTime, server_default=func.now())
    user = relationship("User", back_populates="bookings")
    bike = relationship("Bike", back_populates="bookings")
    payment = relationship("Payment", back_populates="booking", uselist=False)

class Payment(Base):
    __tablename__ = "payments"
    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), unique=True, nullable=False)
    amount = Column(Float, nullable=False)
    method = Column(String(40), default="Demo payment")
    status = Column(String(30), default="paid")
    created_at = Column(DateTime, server_default=func.now())
    booking = relationship("Booking", back_populates="payment")
