from datetime import date
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func
from .database import Base, engine, get_db, SessionLocal
from . import models, schemas
from .auth import hash_password, verify_password, create_token, get_current_user, require_admin

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Bike Rental Management API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# Seed practice bikes and a demo administrator on first run.
def seed_data():
    db = SessionLocal()
    try:
        if not db.query(models.User).filter(models.User.email == "admin@bikerent.com").first():
            db.add(models.User(name="Administrator", email="admin@bikerent.com", hashed_password=hash_password("admin123"), role="admin"))
        if db.query(models.Bike).count() == 0:
            sample = [
                ("Activa 6G", "Honda", "Scooter", 500, "Comfortable scooter for city rides."),
                ("Jupiter", "TVS", "Scooter", 550, "Practical scooter with good storage."),
                ("Access 125", "Suzuki", "Scooter", 600, "Smooth 125cc city scooter."),
                ("Classic 350", "Royal Enfield", "Standard", 1200, "Classic motorcycle for relaxed rides."),
                ("Pulsar NS200", "Bajaj", "Standard", 900, "Sporty bike for everyday riding."),
                ("FZ", "Yamaha", "Standard", 800, "Lightweight street bike."),
                ("Duke 390", "KTM", "Premium", 1500, "Powerful performance motorcycle."),
                ("Himalayan", "Royal Enfield", "Premium", 1800, "Adventure motorcycle for longer journeys.")]
            for name, brand, category, price, desc in sample:
                db.add(models.Bike(name=name, brand=brand, category=category, price_per_day=price, description=desc, image_url=""))
        db.commit()
    finally:
        db.close()
seed_data()

@app.get("/")
def home():
    return {"message": "Bike Rental Management API is running"}

@app.post("/api/auth/register")
def register(data: schemas.RegisterIn, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.email == data.email.lower()).first():
        raise HTTPException(status_code=400, detail="Email is already registered")
    user = models.User(name=data.name.strip(), email=data.email.lower(), hashed_password=hash_password(data.password), role="customer")
    db.add(user); db.commit(); db.refresh(user)
    return {"token": create_token(user), "user": {"id": user.id, "name": user.name, "email": user.email, "role": user.role}}

@app.post("/api/auth/login")
def login(data: schemas.LoginIn, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == data.email.lower()).first()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    return {"token": create_token(user), "user": {"id": user.id, "name": user.name, "email": user.email, "role": user.role}}

@app.get("/api/bikes", response_model=list[schemas.BikeOut])
def list_bikes(db: Session = Depends(get_db)):
    return db.query(models.Bike).order_by(models.Bike.id).all()

@app.post("/api/bikes", response_model=schemas.BikeOut)
def add_bike(data: schemas.BikeIn, db: Session = Depends(get_db), admin=Depends(require_admin)):
    bike = models.Bike(**data.model_dump()); db.add(bike); db.commit(); db.refresh(bike); return bike

@app.put("/api/bikes/{bike_id}", response_model=schemas.BikeOut)
def update_bike(bike_id: int, data: schemas.BikeIn, db: Session = Depends(get_db), admin=Depends(require_admin)):
    bike = db.query(models.Bike).filter(models.Bike.id == bike_id).first()
    if not bike: raise HTTPException(status_code=404, detail="Bike not found")
    for key, value in data.model_dump().items(): setattr(bike, key, value)
    db.commit(); db.refresh(bike); return bike

@app.delete("/api/bikes/{bike_id}")
def delete_bike(bike_id: int, db: Session = Depends(get_db), admin=Depends(require_admin)):
    bike = db.query(models.Bike).filter(models.Bike.id == bike_id).first()
    if not bike: raise HTTPException(status_code=404, detail="Bike not found")
    if db.query(models.Booking).filter(models.Booking.bike_id == bike_id).first():
        raise HTTPException(status_code=400, detail="This bike has booking history and cannot be deleted")
    db.delete(bike); db.commit(); return {"message": "Bike deleted"}

@app.post("/api/bookings")
def create_booking(data: schemas.BookingIn, db: Session = Depends(get_db), user=Depends(get_current_user)):
    if data.start_date < date.today(): raise HTTPException(status_code=400, detail="Start date cannot be in the past")
    if data.end_date < data.start_date: raise HTTPException(status_code=400, detail="End date must be on or after start date")
    bike = db.query(models.Bike).filter(models.Bike.id == data.bike_id, models.Bike.available == True).first()
    if not bike: raise HTTPException(status_code=404, detail="Bike is not available")
    conflict = db.query(models.Booking).filter(models.Booking.bike_id == bike.id, models.Booking.status == "confirmed", models.Booking.start_date <= data.end_date, models.Booking.end_date >= data.start_date).first()
    if conflict: raise HTTPException(status_code=400, detail="Bike is already booked for those dates")
    days = (data.end_date - data.start_date).days + 1
    booking = models.Booking(user_id=user.id, bike_id=bike.id, start_date=data.start_date, end_date=data.end_date, total_amount=days * bike.price_per_day)
    db.add(booking); db.commit(); db.refresh(booking)
    return {"id": booking.id, "bike_name": bike.name, "start_date": booking.start_date, "end_date": booking.end_date, "total_amount": booking.total_amount, "status": booking.status}

@app.get("/api/bookings")
def my_bookings(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.query(models.Booking).options(joinedload(models.Booking.bike), joinedload(models.Booking.payment)).filter(models.Booking.user_id == user.id).order_by(models.Booking.id.desc()).all()
    return [{"id": b.id, "bike_id": b.bike_id, "bike_name": b.bike.name, "brand": b.bike.brand, "start_date": b.start_date, "end_date": b.end_date, "total_amount": b.total_amount, "status": b.status, "payment_status": b.payment.status if b.payment else "Pending"} for b in rows]

@app.patch("/api/bookings/{booking_id}/cancel")
def cancel_booking(booking_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    booking = db.query(models.Booking).filter(models.Booking.id == booking_id, models.Booking.user_id == user.id).first()
    if not booking: raise HTTPException(status_code=404, detail="Booking not found")
    if booking.status == "cancelled": raise HTTPException(status_code=400, detail="Booking is already cancelled")
    booking.status = "cancelled"; db.commit(); return {"message": "Booking cancelled"}

@app.post("/api/bookings/{booking_id}/payment")
def pay_booking(booking_id: int, data: schemas.PaymentIn, db: Session = Depends(get_db), user=Depends(get_current_user)):
    booking = db.query(models.Booking).filter(models.Booking.id == booking_id, models.Booking.user_id == user.id).first()
    if not booking: raise HTTPException(status_code=404, detail="Booking not found")
    if booking.status != "confirmed": raise HTTPException(status_code=400, detail="Only confirmed bookings can be paid")
    if booking.payment: raise HTTPException(status_code=400, detail="Payment already completed")
    payment = models.Payment(booking_id=booking.id, amount=booking.total_amount, method=data.method, status="paid")
    db.add(payment); db.commit(); return {"message": "Demo payment successful", "status": "paid"}

@app.get("/api/admin/dashboard")
def dashboard(db: Session = Depends(get_db), admin=Depends(require_admin)):
    return {"users": db.query(models.User).filter(models.User.role == "customer").count(), "bikes": db.query(models.Bike).count(), "bookings": db.query(models.Booking).count(), "active_bookings": db.query(models.Booking).filter(models.Booking.status == "confirmed").count(), "revenue": db.query(func.coalesce(func.sum(models.Payment.amount), 0)).filter(models.Payment.status == "paid").scalar()}

@app.get("/api/admin/bookings")
def all_bookings(db: Session = Depends(get_db), admin=Depends(require_admin)):
    rows = db.query(models.Booking).options(joinedload(models.Booking.user), joinedload(models.Booking.bike)).order_by(models.Booking.id.desc()).all()
    return [{"id": b.id, "customer": b.user.name, "email": b.user.email, "bike_name": b.bike.name, "start_date": b.start_date, "end_date": b.end_date, "total_amount": b.total_amount, "status": b.status} for b in rows]
