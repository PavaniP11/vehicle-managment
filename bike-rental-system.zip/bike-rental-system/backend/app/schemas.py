from datetime import date
from pydantic import BaseModel, EmailStr, ConfigDict, Field

class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(min_length=6)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class BikeIn(BaseModel):
    name: str
    brand: str
    category: str
    price_per_day: float = Field(gt=0)
    image_url: str = ""
    description: str = ""
    available: bool = True

class BikeOut(BikeIn):
    id: int
    model_config = ConfigDict(from_attributes=True)

class BookingIn(BaseModel):
    bike_id: int
    start_date: date
    end_date: date

class PaymentIn(BaseModel):
    method: str = "Demo payment"
