CREATE DATABASE IF NOT EXISTS bike_rental_db;
USE bike_rental_db;
-- Tables are created automatically by SQLAlchemy when the FastAPI server starts.
-- This file documents the main tables used by the project.
-- users: id, name, email, hashed_password, role, created_at
-- bikes: id, name, brand, category, price_per_day, image_url, description, available
-- bookings: id, user_id, bike_id, start_date, end_date, total_amount, status, created_at
-- payments: id, booking_id, amount, method, status, created_at
