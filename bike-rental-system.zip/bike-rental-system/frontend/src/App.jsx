import { useEffect, useMemo, useState } from 'react';

const API = 'http://127.0.0.1:8000/api';
const money = (value) => `₹${Number(value || 0).toLocaleString('en-IN')}`;
const today = new Date().toISOString().slice(0, 10);

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('ride_token') || '');
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('ride_user') || 'null'));
  const [page, setPage] = useState('bikes');
  const [bikes, setBikes] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats] = useState(null);
  const [adminBookings, setAdminBookings] = useState([]);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [authMode, setAuthMode] = useState('login');
  const [auth, setAuth] = useState({ name: '', email: '', password: '' });
  const [selectedBike, setSelectedBike] = useState(null);
  const [dates, setDates] = useState({ start_date: today, end_date: today });
  const [bikeForm, setBikeForm] = useState({ name: '', brand: '', category: 'Scooter', price_per_day: '', description: '', image_url: '', available: true });
  const [editingBike, setEditingBike] = useState(null);

  async function request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) };
    const response = await fetch(`${API}${path}`, { ...options, headers });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || 'Something went wrong');
    return data;
  }
  function notify(text) { setMessage(text); window.setTimeout(() => setMessage(''), 3500); }
  async function loadBikes() { try { setBikes(await request('/bikes')); } catch (e) { notify(e.message); } }
  async function loadBookings() { if (!token) return; try { setBookings(await request('/bookings')); } catch (e) { notify(e.message); } }
  async function loadAdmin() { try { const [s, b] = await Promise.all([request('/admin/dashboard'), request('/admin/bookings')]); setStats(s); setAdminBookings(b); } catch (e) { notify(e.message); } }
  useEffect(() => { loadBikes(); }, []);
  useEffect(() => { if (token) { loadBookings(); if (user?.role === 'admin') loadAdmin(); } }, [token, user]);

  async function submitAuth(e) {
    e.preventDefault(); setBusy(true);
    try {
      const result = await request(authMode === 'login' ? '/auth/login' : '/auth/register', { method: 'POST', body: JSON.stringify(auth) });
      setToken(result.token); setUser(result.user); localStorage.setItem('ride_token', result.token); localStorage.setItem('ride_user', JSON.stringify(result.user));
      setAuth({ name: '', email: '', password: '' }); notify(`Welcome, ${result.user.name}!`); setPage('bikes');
    } catch (e) { notify(e.message); } finally { setBusy(false); }
  }
  function logout() { setToken(''); setUser(null); localStorage.removeItem('ride_token'); localStorage.removeItem('ride_user'); setPage('bikes'); setBookings([]); notify('You have logged out'); }
  async function bookBike(e) {
    e.preventDefault(); setBusy(true);
    try {
      const result = await request('/bookings', { method: 'POST', body: JSON.stringify({ bike_id: selectedBike.id, ...dates }) });
      notify(`Booking confirmed! Booking #${result.id} — ${money(result.total_amount)}`); setSelectedBike(null); await loadBookings(); setPage('bookings');
    } catch (e) { notify(e.message); } finally { setBusy(false); }
  }
  async function cancelBooking(id) { try { await request(`/bookings/${id}/cancel`, { method: 'PATCH' }); notify('Booking cancelled'); loadBookings(); } catch (e) { notify(e.message); } }
  async function payBooking(id) { try { await request(`/bookings/${id}/payment`, { method: 'POST', body: JSON.stringify({ method: 'Demo payment' }) }); notify('Demo payment successful'); loadBookings(); } catch (e) { notify(e.message); } }
  async function saveBike(e) {
    e.preventDefault(); setBusy(true);
    try {
      const payload = { ...bikeForm, price_per_day: Number(bikeForm.price_per_day) };
      await request(editingBike ? `/bikes/${editingBike}` : '/bikes', { method: editingBike ? 'PUT' : 'POST', body: JSON.stringify(payload) });
      notify(editingBike ? 'Bike updated' : 'Bike added'); setBikeForm({ name: '', brand: '', category: 'Scooter', price_per_day: '', description: '', image_url: '', available: true }); setEditingBike(null); loadBikes();
    } catch (e) { notify(e.message); } finally { setBusy(false); }
  }
  async function removeBike(id) { if (!confirm('Delete this bike?')) return; try { await request(`/bikes/${id}`, { method: 'DELETE' }); notify('Bike deleted'); loadBikes(); } catch (e) { notify(e.message); } }
  function editBike(bike) { setEditingBike(bike.id); setBikeForm({ name: bike.name, brand: bike.brand, category: bike.category, price_per_day: bike.price_per_day, description: bike.description || '', image_url: bike.image_url || '', available: bike.available }); window.scrollTo({ top: 0, behavior: 'smooth' }); }

  const visibleBikes = useMemo(() => bikes.filter(b => `${b.name} ${b.brand}`.toLowerCase().includes(search.toLowerCase()) && (category === 'All' || b.category === category)), [bikes, search, category]);
  const isAdmin = user?.role === 'admin';

  return <div className="app-shell">
    <header className="topbar"><button className="brand" onClick={() => setPage('bikes')}><span className="brand-mark">R</span> RideOn<span className="brand-dot">.</span></button><nav><button className={page === 'bikes' ? 'active' : ''} onClick={() => setPage('bikes')}>Explore bikes</button>{token && <button className={page === 'bookings' ? 'active' : ''} onClick={() => { setPage('bookings'); loadBookings(); }}>My bookings</button>}{isAdmin && <button className={page === 'admin' ? 'active' : ''} onClick={() => { setPage('admin'); loadAdmin(); }}>Admin</button>}</nav><div className="account">{user ? <><span className="welcome">Hi, {user.name.split(' ')[0]}</span><button className="outline small" onClick={logout}>Logout</button></> : <button className="primary small" onClick={() => setPage('auth')}>Login / Register</button>}</div></header>
    {message && <div className="toast">{message}</div>}
    {page === 'bikes' && <>
      <section className="hero"><div className="hero-copy"><span className="eyebrow">YOUR CITY. YOUR RIDE.</span><h1>Find your next<br/><em>two-wheel escape.</em></h1><p>Pick a bike, choose your dates, and get moving. Simple rentals for everyday adventures.</p><button className="primary" onClick={() => document.getElementById('bike-list')?.scrollIntoView({ behavior: 'smooth' })}>Explore bikes <span>↘</span></button></div><div className="hero-art"><div className="sun"></div><div className="road"></div><div className="hero-label">RIDE MORE<br/>WORRY LESS</div><div className="bike-emoji">🏍️</div></div></section>
      <section className="content-section" id="bike-list"><div className="section-heading"><div><span className="eyebrow">THE COLLECTION</span><h2>Choose your ride</h2></div><span className="muted">{visibleBikes.length} bikes available</span></div><div className="filters"><input placeholder="Search by bike or brand..." value={search} onChange={e => setSearch(e.target.value)}/><select value={category} onChange={e => setCategory(e.target.value)}><option>All</option><option>Scooter</option><option>Standard</option><option>Premium</option></select></div>
        <div className="bike-grid">{visibleBikes.map((bike, index) => <article className="bike-card" key={bike.id}><div className={`bike-visual visual-${index % 4}`}><span className="bike-category">{bike.category}</span><span className="bike-icon">{bike.category === 'Scooter' ? '🛵' : '🏍️'}</span><span className="bike-number">0{index + 1}</span></div><div className="bike-info"><div><span className="muted brand-name">{bike.brand}</span><h3>{bike.name}</h3></div><div className="price">{money(bike.price_per_day)}<small> / day</small></div></div><p className="bike-desc">{bike.description || 'A great ride for your next trip.'}</p><button className="primary full" disabled={!bike.available} onClick={() => { if (!token) { notify('Please login before booking'); setPage('auth'); } else { setSelectedBike(bike); setDates({ start_date: today, end_date: today }); } }}>{bike.available ? 'Book this bike' : 'Unavailable'} <span>→</span></button></article>)}</div>
      </section><section className="how"><span className="eyebrow">HOW IT WORKS</span><h2>Three steps to freedom.</h2><div className="steps"><div><b>01</b><h3>Pick a bike</h3><p>Find the ride that fits your plan.</p></div><div><b>02</b><h3>Choose dates</h3><p>Select your pickup and return dates.</p></div><div><b>03</b><h3>Ride away</h3><p>Confirm your booking and enjoy.</p></div></div></section>
    </>}

    {page === 'auth' && <section className="auth-wrap"><div className="auth-panel"><span className="eyebrow">WELCOME TO RIDEON</span><h2>{authMode === 'login' ? 'Good to see you.' : 'Create your account.'}</h2><p className="muted">{authMode === 'login' ? 'Log in to book your next ride.' : 'Join us and find your next ride.'}</p><form onSubmit={submitAuth} className="form-stack">{authMode === 'register' && <label>Full name<input required minLength="2" value={auth.name} onChange={e => setAuth({ ...auth, name: e.target.value })} placeholder="Your name"/></label>}<label>Email address<input required type="email" value={auth.email} onChange={e => setAuth({ ...auth, email: e.target.value })} placeholder="you@example.com"/></label><label>Password<input required minLength="6" type="password" value={auth.password} onChange={e => setAuth({ ...auth, password: e.target.value })} placeholder="At least 6 characters"/></label><button className="primary full" disabled={busy}>{busy ? 'Please wait...' : authMode === 'login' ? 'Login' : 'Create account'}</button></form><p className="switch-auth">{authMode === 'login' ? "Don't have an account?" : 'Already registered?'} <button onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}>{authMode === 'login' ? 'Register' : 'Login'}</button></p><p className="demo-hint">Admin demo: admin@bikerent.com / admin123</p></div></section>}

    {page === 'bookings' && <section className="content-section page-content"><div className="section-heading"><div><span className="eyebrow">YOUR RIDES</span><h2>My bookings</h2></div><button className="outline" onClick={() => setPage('bikes')}>Browse bikes</button></div>{!bookings.length ? <div className="empty"><div>🗓️</div><h3>No bookings yet</h3><p>Your next ride is waiting for you.</p><button className="primary" onClick={() => setPage('bikes')}>Explore bikes</button></div> : <div className="table-wrap"><table><thead><tr><th>Booking</th><th>Bike</th><th>Dates</th><th>Amount</th><th>Status</th><th>Payment</th><th>Actions</th></tr></thead><tbody>{bookings.map(b => <tr key={b.id}><td>#{b.id}</td><td>{b.brand} {b.bike_name}</td><td>{b.start_date} to {b.end_date}</td><td>{money(b.total_amount)}</td><td><span className={`status ${b.status}`}>{b.status}</span></td><td><span className={`status ${b.payment_status === 'paid' ? 'paid' : 'pending'}`}>{b.payment_status}</span></td><td className="actions">{b.status === 'confirmed' && b.payment_status !== 'paid' && <button className="text-button" onClick={() => payBooking(b.id)}>Pay demo</button>}{b.status === 'confirmed' && <button className="text-button danger" onClick={() => cancelBooking(b.id)}>Cancel</button>}</td></tr>)}</tbody></table></div>}</section>}

    {page === 'admin' && isAdmin && <section className="content-section page-content"><div className="section-heading"><div><span className="eyebrow">CONTROL ROOM</span><h2>Admin dashboard</h2></div><button className="outline" onClick={() => { loadAdmin(); loadBikes(); }}>Refresh</button></div>{stats && <div className="stats-grid"><div><span>Total customers</span><strong>{stats.users}</strong></div><div><span>Total bikes</span><strong>{stats.bikes}</strong></div><div><span>Total bookings</span><strong>{stats.bookings}</strong></div><div><span>Confirmed bookings</span><strong>{stats.active_bookings}</strong></div><div><span>Demo revenue</span><strong>{money(stats.revenue)}</strong></div></div>}<div className="admin-layout"><div className="admin-form"><h3>{editingBike ? 'Edit bike' : 'Add a bike'}</h3><form className="form-stack" onSubmit={saveBike}><label>Bike name<input required value={bikeForm.name} onChange={e => setBikeForm({ ...bikeForm, name: e.target.value })}/></label><label>Brand<input required value={bikeForm.brand} onChange={e => setBikeForm({ ...bikeForm, brand: e.target.value })}/></label><label>Category<select value={bikeForm.category} onChange={e => setBikeForm({ ...bikeForm, category: e.target.value })}><option>Scooter</option><option>Standard</option><option>Premium</option></select></label><label>Price per day (₹)<input required type="number" min="1" value={bikeForm.price_per_day} onChange={e => setBikeForm({ ...bikeForm, price_per_day: e.target.value })}/></label><label>Description<input value={bikeForm.description} onChange={e => setBikeForm({ ...bikeForm, description: e.target.value })}/></label><div className="button-row"><button className="primary" disabled={busy}>{editingBike ? 'Save changes' : 'Add bike'}</button>{editingBike && <button type="button" className="outline" onClick={() => { setEditingBike(null); setBikeForm({ name: '', brand: '', category: 'Scooter', price_per_day: '', description: '', image_url: '', available: true }); }}>Clear</button>}</div></form></div><div className="admin-list"><h3>Manage bikes</h3>{bikes.map(b => <div className="manage-row" key={b.id}><div><b>{b.brand} {b.name}</b><small>{money(b.price_per_day)} / day · {b.category}</small></div><div><button className="text-button" onClick={() => editBike(b)}>Edit</button><button className="text-button danger" onClick={() => removeBike(b.id)}>Delete</button></div></div>)}</div></div><h3 className="booking-admin-title">All bookings</h3><div className="table-wrap"><table><thead><tr><th>ID</th><th>Customer</th><th>Bike</th><th>Dates</th><th>Amount</th><th>Status</th></tr></thead><tbody>{adminBookings.map(b => <tr key={b.id}><td>#{b.id}</td><td>{b.customer}<small className="table-sub">{b.email}</small></td><td>{b.bike_name}</td><td>{b.start_date} to {b.end_date}</td><td>{money(b.total_amount)}</td><td><span className={`status ${b.status}`}>{b.status}</span></td></tr>)}</tbody></table></div></section>}

    <footer><div className="brand footer-brand"><span className="brand-mark">R</span> RideOn<span className="brand-dot">.</span></div><span>Practice project · Bike Rental Management System</span><span>Ride safe. Ride free.</span></footer>

    {selectedBike && <div className="modal-backdrop" onClick={() => setSelectedBike(null)}><div className="modal" onClick={e => e.stopPropagation()}><button className="close" onClick={() => setSelectedBike(null)}>×</button><span className="eyebrow">BOOK YOUR RIDE</span><h2>{selectedBike.brand} {selectedBike.name}</h2><p className="muted">{money(selectedBike.price_per_day)} per day</p><form className="form-stack" onSubmit={bookBike}><label>Pickup date<input type="date" required min={today} value={dates.start_date} onChange={e => setDates({ ...dates, start_date: e.target.value, end_date: dates.end_date < e.target.value ? e.target.value : dates.end_date })}/></label><label>Return date<input type="date" required min={dates.start_date || today} value={dates.end_date} onChange={e => setDates({ ...dates, end_date: e.target.value })}/></label><div className="estimate">Estimated total <strong>{money(selectedBike.price_per_day * (Math.max(1, Math.round((new Date(`${dates.end_date}T00:00:00`) - new Date(`${dates.start_date}T00:00:00`)) / 86400000) + 1)))}</strong></div><button className="primary full" disabled={busy}>{busy ? 'Confirming...' : 'Confirm booking'}</button></form><p className="fine-print">Payment is not collected during booking. You can use the demo payment option from My bookings.</p></div></div>}
  </div>;
}
