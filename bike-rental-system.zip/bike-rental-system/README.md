# RideOn — Bike Rental Management System (Practice Project)

A beginner-friendly full-stack practice project built with **React + Vite**, **Python FastAPI**, and **MySQL**.

## Features
- Customer registration and login
- Browse bikes, search and filter by category
- Book a bike for selected dates (checks overlapping bookings)
- View booking history, make a demo payment, and cancel bookings
- Admin dashboard with customer, bike, booking and demo-revenue counts
- Admin can add, edit and delete bikes and view all bookings

> This is a learning/demo project. Payments are simulated; it does not collect card or bank details. The sample admin password is for local practice only. Change it before any real deployment. The app is not production-hardened.

## 1. Requirements
Install these separately:
- Python 3.10+
- Node.js LTS (includes npm)
- MySQL Server (MySQL Workbench is optional)
- VS Code (optional editor)

## 2. Create the MySQL database
Open MySQL Workbench or the MySQL command line and run:

```sql
CREATE DATABASE bike_rental_db;
```

The backend creates the tables automatically the first time it starts.

## 3. Start the backend
Open a terminal in the `backend` folder:

**Windows PowerShell**

```powershell
py -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Open `backend/.env` and replace `YOUR_MYSQL_PASSWORD` with your MySQL root password. If your MySQL username is not `root`, change that too. Set `SECRET_KEY` to a long random value.

Then run:

```powershell
uvicorn app.main:app --reload
```

Backend: http://127.0.0.1:8000  
Interactive API documentation: http://127.0.0.1:8000/docs

If PowerShell blocks virtual-environment activation, run this once in that terminal and activate again:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

## 4. Start the frontend
Open a **second terminal** in the `frontend` folder:

```bash
npm install
npm run dev
```

Open the local URL Vite prints, normally http://localhost:5173.

## 5. Demo login
- Admin email: `admin@bikerent.com`
- Admin password: `admin123`

Customers can create their own account using Register.

## 6. Suggested team split (five people)
1. User Management — register/login/profile
2. Bike Management — bike listing and admin bike CRUD
3. Booking Management — date selection, booking and cancellation
4. Payment Management — demo payment status
5. Admin Dashboard — summary and all-bookings view

For Git collaboration, agree on the API and database models first. Each member should work on a separate feature branch and open a pull request to the shared `main` branch. Avoid creating five separate backend apps or five separate databases.

## Project structure

```text
bike-rental-system/
├── backend/
│   ├── app/
│   │   ├── auth.py
│   │   ├── database.py
│   │   ├── main.py
│   │   ├── models.py
│   │   └── schemas.py
│   ├── .env.example
│   └── requirements.txt
├── database/
│   └── schema.sql
├── frontend/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── style.css
│   ├── index.html
│   └── package.json
└── README.md
```

## Troubleshooting
- **Cannot connect to MySQL:** check that MySQL Server is running, the database exists, and the username/password in `backend/.env` are correct.
- **Frontend says Failed to fetch:** make sure the backend is running at `http://127.0.0.1:8000`.
- **Module not found:** activate the backend virtual environment and run `pip install -r requirements.txt`, or run `npm install` in `frontend`.
- **Admin page is missing:** log in with the demo admin account above.
